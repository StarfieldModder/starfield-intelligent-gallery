"""
sig_main_intro.py — SIG Intro Engine: Main Integration Module
Imports all six layer modules and orchestrates a full cinematic intro sequence.
Supports GUI preview (PySide6) and headless MP4/PNG export (imageio-ffmpeg).

Usage:
    python sig_main_intro.py --preview
    python sig_main_intro.py --render --output intro.mp4 --seed 42
    python sig_main_intro.py --render --output frames/ --format png --seed 42
    python sig_main_intro.py --list-assets
"""
from __future__ import annotations

import argparse
import math
import os
import random
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np

# ---------------------------------------------------------------------------
# Local module imports
# ---------------------------------------------------------------------------
from sig_layer_rings import (
    RingsLayerConfig, generate_rings, render_rings_frame,
)
from sig_layer_glyphs import (
    GlyphsLayerConfig, generate_glyphs, render_glyphs_frame,
)
from sig_layer_hologrid import (
    HologridConfig, render_hologrid_frame,
)
from sig_layer_parallax import (
    ParallaxConfig, build_parallax, render_parallax_frame,
)
from sig_layer_title import (
    TitleConfig, render_title_frame,
)
from sig_layer_audio import (
    AudioMixer, VolumeEnvelope, default_intro_schedule,
    AUDIO_MANIFEST, EVENT_TO_AUDIO,
)

# Optional: import existing engine base if present
try:
    import importlib.util
    _spec = importlib.util.spec_from_file_location(
        "sig_intro_engine",
        Path(__file__).parent / "sig_intro_engine.py"
    )
    if _spec and _spec.loader:
        _engine_mod = importlib.util.module_from_spec(_spec)
        _spec.loader.exec_module(_engine_mod)
        BASE_ENGINE = _engine_mod
    else:
        BASE_ENGINE = None
except Exception:
    BASE_ENGINE = None


# ---------------------------------------------------------------------------
# Sequence configuration
# ---------------------------------------------------------------------------

@dataclass
class IntroSequenceConfig:
    width: int = 1920
    height: int = 1080
    fps: float = 24.0
    duration_sec: float = 8.0
    seed: Optional[int] = None
    headless: bool = False
    audio_cache_dir: str = "cache"

    # Per-layer config overrides (None = use defaults)
    rings_cfg: Optional[RingsLayerConfig] = None
    glyphs_cfg: Optional[GlyphsLayerConfig] = None
    hologrid_cfg: Optional[HologridConfig] = None
    parallax_cfg: Optional[ParallaxConfig] = None
    title_cfg: Optional[TitleConfig] = None

    # Layer timing: (start_frac, end_frac) within full sequence
    layer_timing: dict = field(default_factory=lambda: {
        "parallax":  (0.00, 1.00),
        "hologrid":  (0.05, 0.90),
        "rings":     (0.10, 0.75),
        "glyphs":    (0.20, 0.85),
        "title":     (0.35, 1.00),
    })


# ---------------------------------------------------------------------------
# Frame compositor
# ---------------------------------------------------------------------------

def _alpha_composite(base: np.ndarray, overlay: np.ndarray) -> np.ndarray:
    """Alpha-composite overlay onto base (both RGBA H×W×4 uint8)."""
    b = base.astype(np.float32)
    o = overlay.astype(np.float32)
    oa = o[:, :, 3:4] / 255.0
    ba = b[:, :, 3:4] / 255.0
    out_a = oa + ba * (1.0 - oa)
    safe = np.maximum(out_a, 1e-6)
    out_rgb = (o[:, :, :3] * oa + b[:, :, :3] * ba * (1.0 - oa)) / safe
    result = np.concatenate([out_rgb.clip(0, 255), (out_a * 255).clip(0, 255)], axis=2)
    return result.astype(np.uint8)


def _to_rgb(frame_rgba: np.ndarray, bg: Tuple[int,int,int] = (0, 0, 0)) -> np.ndarray:
    """Flatten RGBA → RGB by compositing over a solid background."""
    H, W = frame_rgba.shape[:2]
    out = np.full((H, W, 3), bg, dtype=np.float32)
    a = frame_rgba[:, :, 3:4].astype(np.float32) / 255.0
    rgb = frame_rgba[:, :, :3].astype(np.float32)
    result = rgb * a + out * (1.0 - a)
    return result.clip(0, 255).astype(np.uint8)


# ---------------------------------------------------------------------------
# Sequence builder
# ---------------------------------------------------------------------------

class IntroSequence:
    def __init__(self, cfg: IntroSequenceConfig):
        self.cfg = cfg
        self.rng = random.Random(cfg.seed)
        self._seed_layers()
        self._build_layers()

    def _seed_layers(self) -> None:
        """Derive per-layer seeds from the master seed."""
        def _s(): return self.rng.randint(0, 2**31)
        self._seeds = {
            "rings":    _s(),
            "glyphs":   _s(),
            "hologrid": _s(),
            "parallax": _s(),
            "title":    _s(),
        }

    def _build_layers(self) -> None:
        cfg = self.cfg
        W, H = cfg.width, cfg.height

        # Parallax
        p_cfg = cfg.parallax_cfg or ParallaxConfig(seed=self._seeds["parallax"])
        self.parallax_cfg, self.parallax_catalogs = build_parallax(W, H, p_cfg)

        # Hologrid
        self.hologrid_cfg = cfg.hologrid_cfg or HologridConfig(
            seed=self._seeds["hologrid"])

        # Rings
        r_cfg = cfg.rings_cfg or RingsLayerConfig(
            num_rings=9, seed=self._seeds["rings"])
        self.rings_cfg = r_cfg
        self.rings = generate_rings(r_cfg, random.Random(self._seeds["rings"]))

        # Glyphs
        g_cfg = cfg.glyphs_cfg or GlyphsLayerConfig(
            asset_dir=str(Path(__file__).parent / "assets" / "glyphs"),
            num_glyphs=6,
            seed=self._seeds["glyphs"],
        )
        self.glyphs_cfg = g_cfg
        self.glyphs = generate_glyphs(g_cfg, random.Random(self._seeds["glyphs"]))

        # Title
        self.title_cfg = cfg.title_cfg or TitleConfig(
            seed=self._seeds["title"])

        # Audio
        self.mixer = AudioMixer(
            cache_dir=cfg.audio_cache_dir,
            headless=cfg.headless,
        )

    def render_frame(self, frame_idx: int) -> np.ndarray:
        """Render a single frame (RGB uint8 H×W×3)."""
        cfg = self.cfg
        total_frames = int(cfg.fps * cfg.duration_sec)
        t_global = frame_idx / max(total_frames - 1, 1)   # [0,1]
        wall_time = frame_idx / cfg.fps

        W, H = cfg.width, cfg.height
        lt = cfg.layer_timing

        def layer_t(name: str) -> float:
            start, end = lt[name]
            if t_global < start:
                return 0.0
            if t_global > end:
                return 1.0
            return (t_global - start) / (end - start)

        # --- parallax (bottom-most) ---
        canvas = np.zeros((H, W, 4), dtype=np.uint8)
        render_parallax_frame(
            canvas, self.parallax_cfg, self.parallax_catalogs,
            layer_t("parallax"), wall_time)

        # --- hologrid ---
        holo = np.zeros((H, W, 4), dtype=np.uint8)
        render_hologrid_frame(
            holo, self.hologrid_cfg,
            layer_t("hologrid"), wall_time,
            random.Random(self._seeds["hologrid"] + frame_idx))
        canvas = _alpha_composite(canvas, holo)

        # --- rings ---
        rings_layer = np.zeros((H, W, 4), dtype=np.uint8)
        render_rings_frame(
            rings_layer, self.rings,
            layer_t("rings"), min(W, H))
        canvas = _alpha_composite(canvas, rings_layer)

        # --- glyphs ---
        glyph_layer = np.zeros((H, W, 4), dtype=np.uint8)
        render_glyphs_frame(
            glyph_layer, self.glyphs,
            layer_t("glyphs"), glyph_size=max(32, H // 16))
        canvas = _alpha_composite(canvas, glyph_layer)

        # --- title (top-most) ---
        title_layer = np.zeros((H, W, 4), dtype=np.uint8)
        render_title_frame(
            title_layer, self.title_cfg,
            layer_t("title"),
            random.Random(self._seeds["title"] + frame_idx))
        canvas = _alpha_composite(canvas, title_layer)

        return _to_rgb(canvas)

    def render_all(self, progress: bool = True) -> List[np.ndarray]:
        cfg = self.cfg
        total = int(cfg.fps * cfg.duration_sec)
        frames = []
        for i in range(total):
            if progress and (i % max(1, total // 20) == 0):
                pct = i / total * 100
                print(f"\r  Rendering… {pct:5.1f}% ({i}/{total})", end="", flush=True)
            frames.append(self.render_frame(i))
        if progress:
            print(f"\r  Rendering… 100.0% ({total}/{total})")
        return frames

    def play_audio(self, realtime: bool = True) -> None:
        schedule = default_intro_schedule(self.cfg.duration_sec)
        self.mixer.schedule(schedule, realtime=realtime)


# ---------------------------------------------------------------------------
# Headless MP4 export (imageio-ffmpeg)
# ---------------------------------------------------------------------------

def export_mp4(
    frames: List[np.ndarray],
    output_path: str,
    fps: float = 24.0,
    quality: int = 8,
) -> None:
    import imageio
    print(f"  Writing MP4 → {output_path} ({len(frames)} frames @ {fps}fps)")
    writer = imageio.get_writer(
        output_path,
        fps=fps,
        quality=quality,
        codec="libx264",
        ffmpeg_params=["-pix_fmt", "yuv420p"],
    )
    for frame in frames:
        writer.append_data(frame)
    writer.close()
    size_mb = os.path.getsize(output_path) / 1e6
    print(f"  Done. File size: {size_mb:.2f} MB")


def export_png_sequence(
    frames: List[np.ndarray],
    output_dir: str,
    prefix: str = "frame",
) -> None:
    import imageio
    os.makedirs(output_dir, exist_ok=True)
    pad = len(str(len(frames)))
    print(f"  Writing {len(frames)} PNG frames → {output_dir}/")
    for i, frame in enumerate(frames):
        path = os.path.join(output_dir, f"{prefix}_{i:0{pad}d}.png")
        imageio.imwrite(path, frame)
    print(f"  Done.")


# ---------------------------------------------------------------------------
# GUI Preview (PySide6)
# ---------------------------------------------------------------------------

def run_preview(seq: IntroSequence) -> None:
    try:
        from PySide6.QtWidgets import QApplication, QLabel, QMainWindow
        from PySide6.QtCore import Qt, QTimer
        from PySide6.QtGui import QImage, QPixmap
    except ImportError:
        print("[preview] PySide6 not available — use --render for headless output.")
        return

    cfg = seq.cfg
    total_frames = int(cfg.fps * cfg.duration_sec)
    frame_ms = int(1000 / cfg.fps)
    current = [0]

    app = QApplication.instance() or QApplication(sys.argv)
    win = QMainWindow()
    win.setWindowTitle("SIG Intro Engine — Preview")
    label = QLabel(win)
    label.setAlignment(Qt.AlignCenter)
    win.setCentralWidget(label)
    win.resize(min(cfg.width, 1280), min(cfg.height, 720))

    def update_frame():
        idx = current[0]
        if idx >= total_frames:
            timer.stop()
            return
        frame = seq.render_frame(idx)
        H, W = frame.shape[:2]
        qimg = QImage(frame.tobytes(), W, H, W * 3, QImage.Format_RGB888)
        pix = QPixmap.fromImage(qimg)
        label.setPixmap(pix.scaled(
            label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        current[0] += 1

    timer = QTimer()
    timer.timeout.connect(update_frame)
    timer.start(frame_ms)

    seq.play_audio(realtime=True)
    win.show()
    sys.exit(app.exec())


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args():
    p = argparse.ArgumentParser(
        description="SIG Intro Engine — cinematic intro renderer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python sig_main_intro.py --preview --seed 42
  python sig_main_intro.py --render --output intro.mp4 --seed 42
  python sig_main_intro.py --render --output frames/ --format png
  python sig_main_intro.py --list-assets
        """
    )
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument("--preview",     action="store_true", help="GUI preview (PySide6)")
    mode.add_argument("--render",      action="store_true", help="Headless render")
    mode.add_argument("--list-assets", action="store_true", help="List audio manifest")

    p.add_argument("--output",   default="intro.mp4",  help="Output path (MP4 or directory)")
    p.add_argument("--format",   default="mp4",        choices=["mp4", "png"], help="Export format")
    p.add_argument("--seed",     type=int, default=None, help="Random seed for reproducibility")
    p.add_argument("--width",    type=int, default=1920)
    p.add_argument("--height",   type=int, default=1080)
    p.add_argument("--fps",      type=float, default=24.0)
    p.add_argument("--duration", type=float, default=8.0, help="Duration in seconds")
    p.add_argument("--quality",  type=int,   default=8,   help="MP4 quality 1-10")
    p.add_argument("--title",    default="SIG", help="Title text")
    p.add_argument("--subtitle", default="Strategic Intelligence Gateway")
    p.add_argument("--download-audio", action="store_true",
                   help="Download audio assets before rendering")
    p.add_argument("--cache-dir", default="cache")
    return p.parse_args()


def main():
    args = parse_args()

    if args.list_assets:
        print("\n=== SIG Audio Asset Manifest ===")
        print(f"{'Key':<25} {'License':<45} {'Source'}")
        print("-" * 85)
        for key, info in AUDIO_MANIFEST.items():
            print(f"{key:<25} {info['license']:<45} {info['source']}")
        print()
        return

    # Build sequence config
    title_cfg = TitleConfig(
        title_text=args.title,
        subtitle_text=args.subtitle,
    )
    seq_cfg = IntroSequenceConfig(
        width=args.width,
        height=args.height,
        fps=args.fps,
        duration_sec=args.duration,
        seed=args.seed,
        headless=not args.preview,
        audio_cache_dir=args.cache_dir,
        title_cfg=title_cfg,
    )

    print(f"\n{'='*60}")
    print(f"  SIG Intro Engine")
    print(f"  Resolution : {args.width}×{args.height}  FPS: {args.fps}")
    print(f"  Duration   : {args.duration}s  Seed: {args.seed}")
    print(f"  Mode       : {'preview' if args.preview else 'render'}")
    print(f"{'='*60}\n")

    seq = IntroSequence(seq_cfg)

    if args.download_audio:
        from sig_layer_audio import download_all, save_manifest
        download_all(args.cache_dir)
        save_manifest(os.path.join(args.cache_dir, "audio_manifest.json"))

    if args.preview:
        run_preview(seq)
    elif args.render:
        frames = seq.render_all(progress=True)
        seq.play_audio(realtime=False)
        if args.format == "mp4":
            export_mp4(frames, args.output, fps=args.fps, quality=args.quality)
        else:
            export_png_sequence(frames, args.output)


if __name__ == "__main__":
    main()

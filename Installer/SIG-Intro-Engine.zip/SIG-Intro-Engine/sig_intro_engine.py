"""
sig_intro_engine.py — SIG Intro Engine Base
Existing engine base module. Provides shared utilities used by all layer modules.
"""
from __future__ import annotations
import time
from typing import Optional

__version__ = "1.0.0"
__author__  = "SIG Project"


class EngineTimer:
    """High-resolution timer for frame scheduling."""
    def __init__(self):
        self._start = time.monotonic()

    def elapsed(self) -> float:
        return time.monotonic() - self._start

    def reset(self) -> None:
        self._start = time.monotonic()


class FrameClock:
    """Tracks frame index and normalised time."""
    def __init__(self, fps: float = 24.0, duration_sec: float = 8.0):
        self.fps = fps
        self.duration_sec = duration_sec
        self.total_frames = int(fps * duration_sec)
        self._index = 0

    @property
    def index(self) -> int:
        return self._index

    @property
    def t(self) -> float:
        """Normalised time [0, 1]."""
        return self._index / max(self.total_frames - 1, 1)

    @property
    def wall_time(self) -> float:
        """Wall-clock seconds from start."""
        return self._index / self.fps

    def advance(self) -> bool:
        """Advance one frame. Returns False when sequence is complete."""
        if self._index >= self.total_frames - 1:
            return False
        self._index += 1
        return True

    def reset(self) -> None:
        self._index = 0


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, value))


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def smoothstep(edge0: float, edge1: float, x: float) -> float:
    t = clamp((x - edge0) / (edge1 - edge0 + 1e-9))
    return t * t * (3.0 - 2.0 * t)

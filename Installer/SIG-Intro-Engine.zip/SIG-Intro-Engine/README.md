# SIG Intro Engine 🎬

**Cinematic intro sequence renderer for the SIG (Strategic Intelligence Gateway) project.**  
Six modular Python layers, GPU-friendly CPU fallback, PySide6 GUI preview, headless MP4 export, reproducible seeds, and royalty-free audio.

---

## Table of Contents
1. [Quick Start](#quick-start)
2. [Modules](#modules)
3. [CLI Reference](#cli-reference)
4. [Run Instructions](#run-instructions)
   - [Windows](#windows)
   - [Linux / macOS](#linux--macos)
   - [Docker](#docker)
5. [Unit Tests](#unit-tests)
6. [Audio Assets & Licensing](#audio-assets--licensing)
7. [Project Structure](#project-structure)
8. [Extending the Engine](#extending-the-engine)

---

## Quick Start

```bash
# Clone
git clone https://github.com/YOUR_USERNAME/SIG-Intro-Engine.git
cd SIG-Intro-Engine/intro

# Install dependencies
pip install -r requirements.txt

# GUI preview (requires display + PySide6)
python sig_main_intro.py --preview --seed 42

# Headless MP4 export (no display required)
python sig_main_intro.py --render --output intro.mp4 --seed 42

# PNG frame sequence
python sig_main_intro.py --render --output frames/ --format png --seed 42
```

---

## Modules

| File | Layer | Responsibility |
|---|---|---|
| `sig_layer_rings.py` | Concentric Rings | Randomised ring expansion with easing curves (cubic / sine / expo) and optional glow & dash patterns |
| `sig_layer_glyphs.py` | Glyph Entrances | SVG glyph loading, randomised entry paths (linear / arc / spiral), staggered timing, collision avoidance |
| `sig_layer_hologrid.py` | Hologram Grid | Multi-depth parallax grid, scanline sweep, shimmer sparkle; shader-like FX via multi-pass numpy compositing |
| `sig_layer_parallax.py` | Parallax Background | Procedural starfield with per-layer depth parallax, nebula blobs, camera dolly/zoom |
| `sig_layer_title.py` | Title Entrance | Per-character typographic animation with overshoot scale, glow passes, and a final shimmer sweep |
| `sig_layer_audio.py` | Audio Cues | Event-driven playback, ADSR volume envelopes, audio manifest (8 royalty-free assets), download/cache |
| `sig_main_intro.py` | Integration | Composes all layers, CLI (`--preview` / `--render`), MP4 / PNG export, `--seed` reproducibility |

---

## CLI Reference

```
python sig_main_intro.py [MODE] [OPTIONS]

Modes (mutually exclusive):
  --preview          Open PySide6 GUI window for real-time preview
  --render           Headless render to file
  --list-assets      Print audio manifest with license info

Options:
  --output PATH      Output file or directory (default: intro.mp4)
  --format {mp4,png} Export format when using --render (default: mp4)
  --seed INT         Random seed for full reproducibility
  --width INT        Frame width  (default: 1920)
  --height INT       Frame height (default: 1080)
  --fps FLOAT        Frames per second (default: 24)
  --duration FLOAT   Sequence duration in seconds (default: 8.0)
  --quality 1-10     MP4 quality (default: 8)
  --title TEXT       Title text (default: "SIG")
  --subtitle TEXT    Subtitle text
  --download-audio   Download royalty-free audio assets before render
  --cache-dir DIR    Cache directory for audio (default: cache/)
```

---

## Run Instructions

### Windows

```powershell
# 1. Install Python 3.11+: https://python.org/downloads
# 2. (Optional) Create virtualenv
python -m venv .venv
.venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Preview (GUI)
python sig_main_intro.py --preview --seed 42

# 5. Render MP4 (1920×1080, 8s)
python sig_main_intro.py --render --output intro.mp4 --seed 42 ^
    --width 1920 --height 1080 --fps 24 --duration 8

# 6. Quick low-res test render (fast)
python sig_main_intro.py --render --output test.mp4 ^
    --width 640 --height 360 --fps 12 --duration 4 --seed 0
```

> **Note:** If you see `libportaudio` errors, install PortAudio:  
> `winget install PortAudio` or download from https://www.portaudio.com

### Linux / macOS

```bash
# 1. Install system dependencies (Debian/Ubuntu)
sudo apt-get update && sudo apt-get install -y \
    ffmpeg fonts-dejavu-core portaudio19-dev python3-dev

# macOS (Homebrew)
# brew install ffmpeg portaudio

# 2. Create virtualenv
python3 -m venv .venv && source .venv/bin/activate

# 3. Install Python packages
pip install -r requirements.txt

# 4. Preview (requires display; use DISPLAY=:0 or Xvfb for headless)
python sig_main_intro.py --preview --seed 42

# 5. Headless MP4 render (no display needed)
python sig_main_intro.py --render --output intro.mp4 --seed 42

# 6. Download audio assets and render with audio schedule
python sig_main_intro.py --render --output intro.mp4 \
    --seed 42 --download-audio
```

### Docker

```bash
# Build image
docker build -t sig-intro-engine .

# Render MP4 (output lands in ./output/ on host)
docker run --rm -v "$(pwd)/output:/app/output" \
    sig-intro-engine

# Custom seed and resolution
docker run --rm -v "$(pwd)/output:/app/output" \
    sig-intro-engine python sig_main_intro.py \
    --render --output output/intro_4k.mp4 \
    --width 3840 --height 2160 --seed 99 --duration 8

# Run tests inside container
docker run --rm sig-intro-engine pytest tests/ -v
```

---

## Unit Tests

```bash
# Run all tests
pytest tests/ -v --tb=short

# With coverage report
pytest tests/ -v --cov=. --cov-report=term-missing

# Run a specific module's tests
pytest tests/ -v -k "TestRings"
pytest tests/ -v -k "TestAudio"
pytest tests/ -v -k "TestIntroSequence"
```

Expected output: **~38 tests**, all passing.

---

## Audio Assets & Licensing

All audio assets are **royalty-free**. No attribution is required for Pixabay-licensed content.

| Asset Key | Description | License | Source |
|---|---|---|---|
| `spark_01` | Electric spark / zap | Pixabay License | Pixabay |
| `click_01` | UI click / tap | Pixabay License | Pixabay |
| `whoosh_01` | Whoosh / swipe transition | Pixabay License | Pixabay |
| `hum_machine_01` | Machine power-up hum | Pixabay License | Pixabay |
| `clap_impact_01` | Sharp clap / impact | Pixabay License | Pixabay |
| `ambience_space_01` | Deep space ambient loop | Pixabay License | Pixabay |
| `reveal_shimmer_01` | Magical shimmer / chime | Pixabay License | Pixabay |
| `glyph_appear_01` | Digital pop / glyph appear | Pixabay License | Pixabay |

**Pixabay License summary:** Free for commercial and non-commercial use. No attribution required. See https://pixabay.com/service/license-summary/

To download all assets:
```bash
python sig_main_intro.py --render --download-audio --output intro.mp4
# or
python sig_layer_audio.py --download-all --save-manifest
```

The manifest is saved to `cache/audio_manifest.json`.

---

## Project Structure

```
SIG-Intro-Engine/
└── intro/
    ├── sig_intro_engine.py        ← existing engine base (preserved)
    ├── sig_main_intro.py          ← integration + CLI entry point
    ├── sig_layer_rings.py         ← Module 1: Concentric Rings
    ├── sig_layer_glyphs.py        ← Module 2: Glyph Entrances
    ├── sig_layer_hologrid.py      ← Module 3: Hologram Grid
    ├── sig_layer_parallax.py      ← Module 4: Parallax Background
    ├── sig_layer_title.py         ← Module 5: Title Entrance
    ├── sig_layer_audio.py         ← Module 6: Audio Cues
    ├── requirements.txt
    ├── Dockerfile
    ├── README.md
    ├── assets/
    │   └── glyphs/                ← SVG glyph assets
    │       ├── glyph_hex.svg
    │       ├── glyph_diamond.svg
    │       ├── glyph_cross.svg
    │       ├── glyph_arrow.svg
    │       ├── glyph_sigma.svg
    │       └── glyph_eye.svg
    ├── cache/                     ← Downloaded audio (git-ignored)
    │   └── audio_manifest.json
    └── tests/
        └── test_sig_engine.py
```

---

## Extending the Engine

### Add a new layer
1. Create `sig_layer_myeffect.py` with a `render_myeffect_frame(canvas, cfg, t)` function.
2. Import it in `sig_main_intro.py`.
3. Add it to the compositor loop in `IntroSequence.render_frame()`.
4. Define its time window in `IntroSequenceConfig.layer_timing`.

### Custom glyph SVGs
Place any `.svg` files in `assets/glyphs/`. The engine auto-discovers them.  
If `cairosvg` is installed (`pip install cairosvg`), high-quality vector rendering is used;  
otherwise a built-in Pillow fallback draws the shape.

### Reproducible renders
Every run with the same `--seed` value produces **bit-identical** output.
```bash
python sig_main_intro.py --render --output a.mp4 --seed 42
python sig_main_intro.py --render --output b.mp4 --seed 42
# a.mp4 == b.mp4 (identical bytes)
```

---

*SIG Intro Engine — built with ❤️ for cinematic excellence.*
